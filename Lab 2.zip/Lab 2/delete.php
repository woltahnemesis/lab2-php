<?php include 'db.php'; ?>

<?php 

if(isset($_GET['id'])){
    $id = $_GET['id'];
    
    $sql = 'DELETE FROM clubs WHERE clubId = :id';
    
    $cmd = $db->prepare($sql);
    $cmd->bindParam(':id', $id, PDO::PARAM_INT);
    $cmd->execute();
    
    $db = null;
    
    header('Location:main.php');

}

?>