<?php include 'db.php'; ?>

<!DOCTYPE html>
<html lang = 'en'>
    <head>
        <meta charset = 'UTF-8'>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <link rel = 'stylesheet' href = 'CSS/main.css'>
        <title>Lab 2</title>
    </head>
    
    <body>
        
        <?php 
        
        if(isset($_GET['id'])){
            
            $id = $_GET['id'];
        }
        
        ?>
        
        <?php 
        
        $sql = "SELECT * FROM clubs WHERE clubId = :id";
        
        $cmd = $db->prepare($sql);
        $cmd->bindParam(':id', $id, PDO::PARAM_INT);
        $cmd->execute();
        
        while($row = $cmd->fetch(PDO::FETCH_ASSOC)){
            $clubName = $row['clubName'];
            $ground = $row['ground'];
        
        ?>
        
        <div class = 'container'>
            
            <h1 class = "text-center mt-5">Edit Page</h1>
            
            <div class = 'col-sm-6 mx-auto mt-5 d-flex justify-content-center'>
                
                <form action = '' method = 'post'>
                    
                    <div class = 'form-group'>
                        <label>Club Name</label>
                        <input type = 'text' name = 'clubName' class = 'form-control' value = "<?php echo $clubName; ?>">
                    </div>
                    
                    <div class = 'form-group'>
                        <label>Ground</label>
                        <input type = 'text' name = 'ground' class = 'form-control' value = "<?php echo $ground; ?>">
                    </div>
                    
                    <div class = 'form-group'>
                        <input type = 'submit' name = 'submit' class = 'btn btn-outline-info' value = 'Submit'>
                    </div>
                    
                </form>
            
            </div>
            
            <?php 
            }
            ?>
            
            <?php 
            
                if(isset($_POST['submit'])){
                    $clubName = $_POST['clubName'];
                    $ground = $_POST['ground'];
                    
                    $sql = "UPDATE clubs SET clubName = :clubName, ground = :ground ";
                    $sql .= "WHERE clubId = :id";
                    
                    $cmd = $db->prepare($sql);
                
                    $cmd->bindParam(':id', $id, PDO::PARAM_INT);                
                    $cmd->bindParam(':clubName', $clubName, PDO::PARAM_STR);
                    $cmd->bindParam(':ground', $ground, PDO::PARAM_STR);
                    
                    $cmd->execute();
                    
                    $db = null;
                    
                    header('Location: main.php');
                    
                    
                }
                
            ?>
            
            <footer class = 'mx-auto mt-5 d-flex justify-content-center'>
                <small>&copy All Rights Reserved</small>
            </footer>
        </div>
        
    </body>
    
</html>