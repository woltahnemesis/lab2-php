<?php include 'db.php'; ?>

<!DOCTYPE html>
<html lang = 'en'>
    <head>
        <meta charset = 'UTF-8'>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <script src = "Script/lab2_script.js" async></script>
        <link rel = 'stylesheet' href = 'CSS/main.css'>
        <title>Lab 2</title>
    </head>
    
    <body>
        
        <div class = 'container '>
            
            <h1 class = "text-center mt-5">Table</h1>
            
            <div class = 'col-sm-6 mx-auto mt-5 d-flex justify-content-center' >
                
                <table class = 'table table-bordered table-info table-hover' id = "main-table">
                    <thead>
                        <tr>
                            <th>Club Name</th>
                            <th>Ground</th>
                        </tr>
                    </thead>
                    <tbody>
            
                <?php 
                
                $sql = "SELECT * FROM clubs";
                
                $cmd = $db->prepare($sql);
                $cmd->execute();
                
                while($row = $cmd->fetch(PDO::FETCH_ASSOC)){
                    $clubId = $row['clubId'];
                    $clubName = $row['clubName'];
                    $ground = $row['ground'];
                ?>
                        <tr>
                            <td><?php echo $clubName; ?></td>
                            <td><?php echo $ground; ?></td>
                            <td><a href = "edit.php?id=<?php echo $clubId; ?>">EDIT</a></td>
                            <td><a href = "delete.php?id=<?php echo $clubId; ?>" onclick = 'confirmDelete()'>DELETE</a></td>
                        </tr>
                <?php 
                }
                    
                        
                $db = null;
                ?>
                        
                    </tbody>
                </table>
            
            </div>
            
            <footer class = 'mx-auto d-flex justify-content-center'>
                <small>&copy All Rights Reserved</small>
            </footer>
        </div>
        
    </body>
    
</html>