<?php $db = new PDO('mysql:host=127.0.0.1:8889;dbname=lab2','root','root') ;

    if(!$db){
        echo 'Database connection failed.';
    }

?>